import java.util.ArrayList;
import java.util.List;

class Buffer {
    private int c;
    private final List<Integer> data = new ArrayList<>();
    private final List<Integer> dataPar = new ArrayList<>();

    public void put(int value) {
        if(this.c != 100){

            if(value%2 == 0){
                dataPar.add(value);

                System.out.println("Inserted even: " + value + " | Buffer size: " + dataPar.size());
            }else{
                data.add(value);
                System.out.println("Inserted odd: " + value + " | Buffer size: " + data.size());
            }
        
        }
    }

    public synchronized void inc(){
        this.c++;
    }

    public synchronized int get(){

        return this.c;
    }
    
    public int remove() {
        if (!data.isEmpty()) {

            int valueImpar = data.remove(0);
            System.out.println("Removed odd: " + valueImpar + " | Buffer size: " + data.size());
            return valueImpar;
    
        }else if(!dataPar.isEmpty()){
    
            int valuePar = dataPar.remove(0);
            System.out.println("Removed even: " + valuePar + " | Buffer size: " + dataPar.size());
            return valuePar;
    
        }
        return -1;
    }


    
}
