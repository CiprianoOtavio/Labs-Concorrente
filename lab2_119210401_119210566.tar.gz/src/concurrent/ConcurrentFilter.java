import java.awt.image.BufferedImage;

public class ConcurrentFilter implements Runnable{

    BufferedImage originalImage;
    final int kernelSize = 7;
    BufferedImage filteredImage;
    int yValue;
    int yRange;
    int xValue;
    int xRange;

    public ConcurrentFilter(BufferedImage originalImage, BufferedImage filteredImage, int yValue, int yRange, int xValue, int xRange){

    }

    @Override
    public void run(){
// Process each pixel
        for (int y = yValue; y < yRange; y++) {
            for (int x = xValue; x < xRange; x++) {
                // Calculate neighborhood average
                int[] avgColor = calculateNeighborhoodAverage(originalImage, x, y);

                // Set filtered pixel
                filteredImage.setRGB(x, y,
                        (avgColor[0] << 16) |
                                (avgColor[1] << 8)  |
                                avgColor[2]
                );
            }
        }
    }

    /**
     * Calculates average colors in a pixel's neighborhood
     *
     * @param image      Source image
     * @param centerX    X coordinate of center pixel
     * @param centerY    Y coordinate of center pixel
     * @return Array with R, G, B averages
     */
    private int[] calculateNeighborhoodAverage(BufferedImage image, int centerX, int centerY) {
        int width = image.getWidth();
        int height = image.getHeight();
        int pad = this.kernelSize / 2;

        // Arrays for color sums
        long redSum = 0, greenSum = 0, blueSum = 0;
        int pixelCount = 0;

        // Process neighborhood
        for (int dy = -pad; dy <= pad; dy++) {
            for (int dx = -pad; dx <= pad; dx++) {
                int x = centerX + dx;
                int y = centerY + dy;

                // Check image bounds
                if (x >= 0 && x < width && y >= 0 && y < height) {
                    // Get pixel color
                    int rgb = image.getRGB(x, y);

                    // Extract color components
                    int red = (rgb >> 16) & 0xFF;
                    int green = (rgb >> 8) & 0xFF;
                    int blue = rgb & 0xFF;

                    // Sum colors
                    redSum += red;
                    greenSum += green;
                    blueSum += blue;
                    pixelCount++;
                }
            }
        }

        // Calculate average
        return new int[] {
                (int)(redSum / pixelCount),
                (int)(greenSum / pixelCount),
                (int)(blueSum / pixelCount)
        };
    }

}
