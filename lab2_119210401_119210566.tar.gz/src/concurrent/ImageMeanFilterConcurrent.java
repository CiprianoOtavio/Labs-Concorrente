import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * This class provides functionality to apply a mean filter to an image.
 * The mean filter is used to smooth images by averaging the pixel values
 * in a neighborhood defined by a kernel size.
 * 
 * <p>Usage example:</p>
 * <pre>
 * {@code
 * ImageMeanFilter.applyMeanFilter("input.jpg", "output.jpg", 3);
 * }
 * </pre>
 * 
 * <p>Supported image formats: JPG, PNG</p>
 * 
 * <p>Author: temmanuel@comptuacao.ufcg.edu.br</p>
 */
public class ImageMeanFilterConcurrent {

    /**
     * Applies mean filter to an image
     *
     * @param inputPath  Path to input image
     * @param outputPath Path to output image
     * @param kernelSize Size of mean kernel
     * @throws IOException If there is an error reading/writing
     */
    public static void applyMeanFilter(String inputPath, String outputPath, int kernelSize) throws IOException {
        // Load image
        BufferedImage originalImage = ImageIO.read(new File(inputPath));

        // Create result image
        BufferedImage filteredImage = new BufferedImage(
            originalImage.getWidth(),
            originalImage.getHeight(),
            BufferedImage.TYPE_INT_RGB
        );

        // Image processing
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();

        ConcurrentFilter concurrenFilter1 = new ConcurrentFilter(originalImage, filteredImage, 0, height%2, 0, width%2);
        ConcurrentFilter concurrenFilter2 = new ConcurrentFilter(originalImage, filteredImage, (height%2) + 1, height, (width%2) + 1, width);

        Thread t1 = new Thread(concurrenFilter1);
        Thread t2 = new Thread(concurrenFilter2);

        t1.start();
        t2.start();

        // Save filtered image
        ImageIO.write(filteredImage, "jpg", new File(outputPath));
    }


    /**
     * Main method for demonstration
     * 
     * Usage: java ImageMeanFilter <input_file>
     * 
     * Arguments:
     *   input_file - Path to the input image file to be processed
     *                Supported formats: JPG, PNG
     * 
     * Example:
     *   java ImageMeanFilter input.jpg
     * 
     * The program will generate a filtered output image named "filtered_output.jpg"
     * using a 7x7 mean filter kernel
     */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.err.println("Usage: java ImageMeanFilter <input_file>");
            System.exit(1);
        }

        String inputFile = args[0];
        try {
            applyMeanFilter(inputFile, "filtered_output.jpg", 7);
        } catch (IOException e) {
            System.err.println("Error processing image: " + e.getMessage());
        }
    }
}
