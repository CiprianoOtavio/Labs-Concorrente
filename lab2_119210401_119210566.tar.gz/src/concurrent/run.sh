#!/bin/bash

if [ $# -lt 2 ]; then
  echo "Erro: Informe o caminho da imagem e o número de threads como parâmetros."
  exit 1
fi

IMAGE_PATH=$1
THREADS=$2

javac ImageMeanFilterConcurrent.java
time java ImageMeanFilterConcurrent "$IMAGE_PATH" "$THREADS"
