cd serial
time python3 cript.py ../../dataset
cd ../concurrent
time python3 cript.py ../../dataset
