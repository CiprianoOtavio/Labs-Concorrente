
import java.io.File;

public class PasswordProcessorConcurrent {
    public static void main(String[] args) throws InterruptedException {
        if (args.length < 1) {
            System.out.println("Uso: java PasswordProcessorSerial <caminho_do_diretorio>");
            return;
        }

        String directoryPath = args[0]; // Recebe o caminho como argumento

        File directory = new File(directoryPath);
        if (!directory.exists() || !directory.isDirectory()) {
            System.out.println("Erro: Diretório não encontrado ou inválido.");
            return;
        }

        File[] files = directory.listFiles((dir, name) -> name.endsWith(""));
        if (files == null) {
            System.out.println("Erro ao listar arquivos no diretório.");
            return;
        }

        for (File file : files) {
            ProcessFile processFile = new ProcessFile(file);
            Thread processThread = new Thread(processFile, "myThread-ProcessFile");
            processThread.start();
            processThread.join();
        }
    }
}


