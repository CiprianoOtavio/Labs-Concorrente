package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	ch := make(chan int, 100)

	go produtor(ch, ch, rand.Intn(100))
	go produtor(ch, ch, rand.Intn(100))
	go consumidor(ch, ch)

	time.Sleep((3 * time.Millisecond))
}

func produtor(in <-chan int, out chan<- int, tamanho int) {

	for i := 0; i < tamanho; i++ {
		n := rand.Intn(100)
		fmt.Printf("produzido (%d) \n", n)
		out <- n
	}

}

func consumidor(in <-chan int, out chan<- int) {
	for y := range in {
		if y > 50 {
			fmt.Printf("consumido (%d) \n", y)

		}

	}
}
