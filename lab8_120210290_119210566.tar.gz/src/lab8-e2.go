package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	ch := make(chan int)

	go produtor(ch)
	go consumidor(ch)

	time.Sleep((3 * time.Millisecond))
}

func produtor(my_chan chan int) {

	for i := 0; i < 10000; i++ {
		n := rand.Intn(100)
		fmt.Printf("produzido (%d) \n", n)
		my_chan <- n
	}

}

func consumidor(my_chan chan int) {
	for y := range my_chan {
		if y > 50 {
			fmt.Printf("consumido (%d) \n", y)

		}

	}
}
