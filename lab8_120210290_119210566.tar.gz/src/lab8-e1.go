package main

import (
	"fmt"
	"math/rand"
)

func main() {
	ch := make(chan int)
	join_ch := make(chan int)

	go produtor(ch)
	go consumidor(ch)

	<-join_ch
}

func produtor(my_chan chan int) {

	for {
		n := rand.Intn(100)
		//fmt.Printf("produzido (%d) \n", n)
		my_chan <- n
	}
}

func consumidor(my_chan chan int) {
	for {
		y := <-my_chan
		if y > 50 {
			fmt.Printf("consumido (%d) \n", y)
		}
	}
}
