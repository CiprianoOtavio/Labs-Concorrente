import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class LogAnalyzer3s {

        static class ProcessFileThread implements Runnable{
            String fileName;

            public ProcessFileThread(String fileName){
                this.fileName = fileName;
            }

            @Override
            public void run(){
                try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
                    
                    String line;

                    while ((line = br.readLine()) != null) {
                        String[] parts = line.split(" ");
                        if (parts.length == 3) {
                            String code = parts[2];
                            if (code.equals("200")) {
                                total200++;
                            } else if (code.equals("500")) {
                                total500++;
                            }
                        }
                    }
                } catch (IOException e) {
                    System.err.println("Erro ao ler arquivo: " + fileName);
                    e.printStackTrace();
                }
            }
        }
        static int total200 = 0;
        static int total500 = 0;


public static void main(String[] args) throws InterruptedException {
    if (args.length == 0) {
        System.out.println("Uso: java LogAnalyzer <arquivfileNameos_de_log>");
        System.exit(1);
    }

    //int total200 = 0;
    //int total500 = 0;

    ExecutorService exService = Executors.newSingleThreadExecutor();

    for (String fileName : args) {
        System.out.println("Processando arquivo: " + fileName);
        ProcessFileThread processT = new ProcessFileThread(fileName);
        exService.execute(processT);        
        
    }

    exService.shutdown();
    exService.awaitTermination(500, TimeUnit.MILLISECONDS);
    System.out.println("===== RESULTADO FINAL =====");
    System.out.println("Total 200: " + total200);
    System.out.println("Total 500: " + total500);
}
}

